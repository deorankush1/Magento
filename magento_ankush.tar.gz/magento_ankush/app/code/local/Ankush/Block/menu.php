class Ankush_Hello_Menu extends Mage_Core_Block_Template 
{    
    
}