<?php

class Ankush_Pincode_Model_Mysql4_Pincode_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
	function _construct()
	{
		$this->_init('pincode/pincode');
	}
}
?>